#include <WiFi.h>
#include <ArduinoJson.h>
#include <WebSocketsClient.h>
#include "DHT.h"

// ==========================================
// KONFIGURASI PERANGKAT KERAS
// ==========================================
#define DHTPIN 5
#define DHTTYPE DHT22
#define POT_PIN 4
#define LED_PIN_ONOFF 6  
#define LED_PIN_PWM 7  

// ==========================================
// KONFIGURASI WiFi
// ==========================================
const char* ssid = "uniot";
const char* password = "12345678";

// ==========================================
// KONFIGURASI SERVER UNIOT
// ==========================================
const char* ws_host = "192.168.xxx.xxx";  // IP Server UNIOT
const int ws_port = 3001;               // Port Server
const char* secret_key = "xxxxxx";      // Secret key dari dashboard (6 karakter)

// ==========================================
// INISIALISASI GLOBAL
// ==========================================
WebSocketsClient webSocket;
DHT dht(DHTPIN, DHTTYPE);

unsigned long lastPotRead = 0;
unsigned long lastDHTRead = 0;
bool isConnected = false;

// Variabel untuk melacak data terakhir potensiometer
float lastSentPotVal = -100.0; 

// ==========================================
// FUNGSI SUBSCRIBER: EKSEKUSI PERINTAH AKTUATOR
// ==========================================
void eksekusiAktuator(const char* sensorType, const char* value) {
  
  // Kontrol digital LED (Pin 6)
  if (strcmp(sensorType, "kondisi-led") == 0) {
    bool state = (strcmp(value, "true") == 0 || strcmp(value, "1") == 0);
    digitalWrite(LED_PIN_ONOFF, state ? HIGH : LOW);
    Serial.printf("EKSEKUSI: LED (Pin 6) diubah menjadi %s\n", state ? "ON" : "OFF");
  }
  
  // Kontrol PWM LED (Pin 7)
  else if (strcmp(sensorType, "pwm-led") == 0) {
    int pwmValue = constrain(atoi(value), 0, 255);
    analogWrite(LED_PIN_PWM, pwmValue);
    Serial.printf("EKSEKUSI: PWM (Pin 7) diubah menjadi %d/255\n", pwmValue);
  }
  
  else {
    Serial.printf("Aktuator tidak dikenali: %s\n", sensorType);
  }
}

// ==========================================
// CALLBACK: HANDLING EVENT WEBSOCKET
// ==========================================
void webSocketEvent(WStype_t type, uint8_t* payload, size_t length) {
  switch (type) {
    
    case WStype_DISCONNECTED: {
      isConnected = false;
      Serial.println("[WS] Terputus dari server UNIOT");
      Serial.println("[WS] Mencoba menyambung kembali...");
      break;
    }

    case WStype_CONNECTED: {
      isConnected = true;
      Serial.println("[WS] Terhubung ke WebSocket UNIOT Server");
      Serial.println("[WS] Siap melakukan pengiriman dan penerimaan data\n");
      break;
    }

    case WStype_TEXT: {
      StaticJsonDocument<256> doc;
      DeserializationError error = deserializeJson(doc, payload, length);

      if (error) {
        Serial.printf("[JSON] Gagal melakukan parse: %s\n", error.c_str());
        break;
      }

      const char* sensorType = doc["var"];
      const char* value = doc["current_value"]; 

      // Fallback data parameter alternatif
      if (!value) {
        value = doc["val"];
      }

      if (!sensorType || !value) {
        break;
      }

      Serial.printf("[WS] Data masuk dari dashboard: %s = %s\n", sensorType, value);
      eksekusiAktuator(sensorType, value);
      break;
    }

    case WStype_PING: {
      Serial.println("[WS] PING diterima");
      break;
    }

    case WStype_PONG: {
      Serial.println("[WS] PONG dikirim");
      break;
    }

    case WStype_ERROR: {
      Serial.printf("[WS] Error: %s\n", payload);
      break;
    }

    default:
      break;
  }
}

// ==========================================
// FUNGSI PUBLISHER: KIRIM DATA SENSOR
// ==========================================
void kirimDataWebSocket(const char* sensor_type, float value) {
  if (!isConnected) return; 

  StaticJsonDocument<128> doc;
  doc["var"] = sensor_type;
  doc["val"] = value;

  String jsonString;
  serializeJson(doc, jsonString);

  webSocket.sendTXT(jsonString); 
  Serial.printf("Data Terkirim [%s]: %.2f\n", sensor_type, value);
}

// ==========================================
// INIDIALISASI SISTEM (SETUP)
// ==========================================
void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n========================================");
  Serial.println("   UNIOT ESP32 Pure WebSocket v2.1");
  Serial.println("   (Secret Key Authentication)");
  Serial.println("========================================\n");

  // Inisialisasi sensor DHT22
  dht.begin();
  Serial.println("[SENSOR] DHT22 siap");

  // Inisialisasi parameter pin output
  pinMode(LED_PIN_ONOFF, OUTPUT);
  digitalWrite(LED_PIN_ONOFF, LOW);
  pinMode(LED_PIN_PWM, OUTPUT);
  analogWrite(LED_PIN_PWM, 0);
  Serial.println("[AKTUATOR] Perangkat LED siap");

  // Koneksi jaringan Wi-Fi
  Serial.printf("[WiFi] Menghubungkan ke: %s...\n", ssid);
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  int wifiTimeout = 0;
  while (WiFi.status() != WL_CONNECTED && wifiTimeout < 20) {
    delay(500);
    Serial.print(".");
    wifiTimeout++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Terhubung. IP Address: %s\n\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\n[WiFi] Koneksi gagal. Periksa kembali SSID dan Password!");
    return;
  }

  // Koneksi ke WebSocket Server
  Serial.printf("[WS] Membuka koneksi tunnel ke: ws://%s:%d\n", ws_host, ws_port);
  
  // Autentikasi menggunakan parameter Secret Key
  String ws_path = String("/") + "?key=" + String(secret_key);
  
  webSocket.begin(ws_host, ws_port, ws_path.c_str());
  webSocket.onEvent(webSocketEvent);
  webSocket.setReconnectInterval(5000);  
  
  Serial.println("[SETUP] Konfigurasi selesai. Menunggu koneksi...\n");
}

// ==========================================
// SIKLUS PROSES UTAMA (LOOP)
// ==========================================
void loop() {
  // Menjaga koneksi WebSocket tetap aktif
  webSocket.loop();
  
  unsigned long now = millis();

  // ===== PUBLISH POTENSIOMETER (Menggunakan filter delta perubahan) =====
  if (now - lastPotRead > 500) {
    lastPotRead = now;
    int rawVal = analogRead(POT_PIN);
    float potVal = map(rawVal, 0, 4095, 0, 100);

    // Kirim data hanya jika terdapat deviasi nilai sebesar >= 1.0
    if (abs(potVal - lastSentPotVal) >= 1.0) {
      kirimDataWebSocket("potensiometer", potVal);
      lastSentPotVal = potVal; 
    }
  }

  // ===== PUBLISH DATA REAL DHT22 (Interval 2000ms) =====
  if (now - lastDHTRead > 2000) {
    lastDHTRead = now;
    
    // Pembacaan sensor riil melalui komponen library DHT
    float temperature = dht.readTemperature(); 
    float humidity = dht.readHumidity();       

    // Validasi integritas hasil pembacaan sensor fisik
    if (isnan(temperature) || isnan(humidity)) {
      Serial.println("[SENSOR] Error: Gagal membaca data dari modul fisik DHT22!");
    } else {
      kirimDataWebSocket("suhu", temperature);
      kirimDataWebSocket("kelembapan", humidity);
      
      Serial.printf("[SENSOR] Log data - Suhu: %.1f C, Kelembapan: %.1f %%\n", temperature, humidity);
    }
  }
}
